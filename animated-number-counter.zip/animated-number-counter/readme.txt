=== Animated Number Counter ===
Contributors: cpcdev84
Donate link: http://activetechnologies.com/
Tags: comments, spam
Requires at least: 2.5
Tested up to: 4.3.5
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Animated Number Counter lets you apply an animated number counter effect to any number of your choosing. 

== Description ==

Animated Number Counter lets you apply an animated number counter effect to any text of your choosing. Simply install and activate the plugin then follow the usage instructions

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Follow the simple usage instructions at http://activetechnologies.com/animated-number-counter/


== Frequently Asked Questions ==

= What class do I use to apply the text effect? =

Use the "anc" class.

= Can I use letters and symbols? =

No, Animated Number Counter only works with numbers. If you'd like to "count" letters, please see my plugin "Animated Letter Incrementer".